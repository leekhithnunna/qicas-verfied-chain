QICAS-Chain project report (Team 07, 23CSE335, Semester VII, November 2026) - version 2 (46 pages)
Build: pdflatex main.tex   (run 3 times so the contents, lists and references resolve). Works on Overleaf (pdfLaTeX).
chapters/00_frontmatter.tex ... 09_references.tex; figures/ holds all images.
